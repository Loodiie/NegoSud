package com.cesi.client_lourd_negosud.models;

public class Orderline {

    int idOrderLine;
    int quantityOrderLine;
    Article article;
    WineOrder wineOrder;

    public int getIdOrderLine() {
        return idOrderLine;
    }

    public void setIdOrderLine(int idOrderLine) {
        this.idOrderLine = idOrderLine;
    }

    public int getQuantityOrderLine() {
        return quantityOrderLine;
    }

    public void setQuantityOrderLine(int quantityOrderLine) {
        this.quantityOrderLine = quantityOrderLine;
    }

    public Article getArticle() {
        return article;
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public WineOrder getWineOrder() {
        return wineOrder;
    }

    public void setWineOrder(WineOrder wineOrder) {
        this.wineOrder = wineOrder;
    }
}
