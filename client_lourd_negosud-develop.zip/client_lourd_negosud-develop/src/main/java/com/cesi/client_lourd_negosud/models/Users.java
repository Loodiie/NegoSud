package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.*;

import java.sql.Timestamp;

public class Users {

    private final SimpleIntegerProperty idUser;
    private final SimpleStringProperty userName;
    private final SimpleStringProperty userSurname;
    private final SimpleStringProperty userPhone;
    private final SimpleStringProperty userEmail;
    private final SimpleStringProperty password;
    private final SimpleBooleanProperty admin;
    private final ObjectProperty<Address> address;


    public Users(@JsonProperty("idUser") Integer idUser,
                 @JsonProperty("userName") String userName,
                 @JsonProperty("userSurname") String userSurname,
                 @JsonProperty("userPhone") String userPhone,
                 @JsonProperty("userEmail") String userEmail,
                 @JsonProperty("password") String password,
                @JsonProperty("admin") Boolean admin,
                @JsonProperty("address") Address address) {

        this.idUser = new SimpleIntegerProperty(idUser);
        this.userName = new SimpleStringProperty(userName);
        this.userSurname = new SimpleStringProperty(userSurname);
        this.userPhone = new SimpleStringProperty(userPhone);
        this.userEmail = new SimpleStringProperty(userEmail);
        this.password = new SimpleStringProperty(password);
        this.admin = new SimpleBooleanProperty(admin);
        this.address = new SimpleObjectProperty<>(address);
    }


    public int getIdUser() {
        return idUser.get();
    }

    public SimpleIntegerProperty idUserProperty() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser.set(idUser);
    }

    public String getUserName() {
        return userName.get();
    }

    public SimpleStringProperty userNameProperty() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName.set(userName);
    }

    public String getUserSurname() {
        return userSurname.get();
    }

    public SimpleStringProperty userSurnameProperty() {
        return userSurname;
    }

    public void setUserSurname(String userSurname) {
        this.userSurname.set(userSurname);
    }

    public String getUserPhone() {
        return userPhone.get();
    }

    public SimpleStringProperty userPhoneProperty() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone.set(userPhone);
    }

    public String getUserEmail() {
        return userEmail.get();
    }

    public SimpleStringProperty userEmailProperty() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail.set(userEmail);
    }

    public String getPassword() {
        return password.get();
    }

    public SimpleStringProperty passwordProperty() {
        return password;
    }

    public void setPassword(String password) {
        this.password.set(password);
    }

    public boolean isAdmin() {
        return admin.get();
    }

    public SimpleBooleanProperty adminProperty() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin.set(admin);
    }

    public Address getAddress() {
        return address.get();
    }

    public ObjectProperty<Address> addressProperty() {
        return address;
    }

    public void setAddress(Address address) {
        this.address.set(address);
    }
}




