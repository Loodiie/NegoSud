package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Family {

    private final SimpleIntegerProperty idFamily;
    private final SimpleStringProperty familyName;
    private final SimpleStringProperty familyDescription;

    public Family(@JsonProperty("id_family") int idFamily,
                  @JsonProperty("family_name") String familyName,
                  @JsonProperty("family_description") String familyDescription) {
        this.idFamily = new SimpleIntegerProperty(idFamily);
        this.familyName = new SimpleStringProperty(familyName);
        this.familyDescription = new SimpleStringProperty(familyDescription);
    }

    public int getIdFamily() {
        return idFamily.get();
    }

    public SimpleIntegerProperty idFamilyProperty() {
        return idFamily;
    }

    public void setIdFamily(int idFamily) {
        this.idFamily.set(idFamily);
    }

    public String getFamilyName() {
        return familyName.get();
    }

    public SimpleStringProperty familyNameProperty() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName.set(familyName);
    }

    public String getFamilyDescription() {
        return familyDescription.get();
    }

    public SimpleStringProperty familyDescriptionProperty() {
        return familyDescription;
    }

    public void setFamilyDescription(String familyDescription) {
        this.familyDescription.set(familyDescription);
    }

}
