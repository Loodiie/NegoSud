package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;


public class Supplier {

    private final SimpleIntegerProperty idSupplier;
    private final SimpleStringProperty supplierName;
    private final SimpleStringProperty supplierPhone;
    private final SimpleStringProperty supplierMail;
    private final ObjectProperty<Address> address;

    public Supplier(@JsonProperty("idSupplier") Integer idSupplier,
                 @JsonProperty("supplierName") String supplierName,
                 @JsonProperty("supplierPhone") String supplierPhone,
                 @JsonProperty("supplierMail") String supplierMail,
                 @JsonProperty("address") Address address) {
        this.idSupplier = new SimpleIntegerProperty(idSupplier);
        this.supplierName = new SimpleStringProperty(supplierName);
        this.supplierPhone = new SimpleStringProperty(supplierPhone);
        this.supplierMail = new SimpleStringProperty(supplierMail);
        this.address = new SimpleObjectProperty<>(address);
    }

    public int getIdSupplier() {
        return idSupplier.get();
    }

    public SimpleIntegerProperty idSupplierProperty() {
        return idSupplier;
    }

    public void setIdSupplier(int idSupplier) {
        this.idSupplier.set(idSupplier);
    }

    public String getSupplierName() {
        return supplierName.get();
    }

    public SimpleStringProperty supplierNameProperty() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName.set(supplierName);
    }

    public String getSupplierPhone() {
        return supplierPhone.get();
    }

    public SimpleStringProperty supplierPhoneProperty() {
        return supplierPhone;
    }

    public void setSupplierPhone(String supplierPhone) {
        this.supplierPhone.set(supplierPhone);
    }

    public String getSupplierMail() {
        return supplierMail.get();
    }

    public SimpleStringProperty supplierMailProperty() {
        return supplierMail;
    }

    public void setSupplierMail(String supplierMail) {
        this.supplierMail.set(supplierMail);
    }

    public Address getAddress() {
        return address.get();
    }

    public ObjectProperty<Address> addressProperty() {
        return address;
    }

    public void setAddress(Address address) {
        this.address.set(address);
    }
}
