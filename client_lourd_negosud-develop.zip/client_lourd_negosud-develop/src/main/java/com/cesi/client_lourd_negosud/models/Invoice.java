package com.cesi.client_lourd_negosud.models;

import java.sql.Timestamp;

public class Invoice {

    int idInvoice;
    float vatRate;
    float markup;
    Timestamp invoiceDate;
    String invoiceStatus;
    WineOrder wineOrder;

    public int getIdInvoice() {
        return idInvoice;
    }

    public void setIdInvoice(int idInvoice) {
        this.idInvoice = idInvoice;
    }

    public float getVatRate() {
        return vatRate;
    }

    public void setVatRate(float vatRate) {
        this.vatRate = vatRate;
    }

    public float getMarkup() {
        return markup;
    }

    public void setMarkup(float markup) {
        this.markup = markup;
    }

    public Timestamp getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Timestamp invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public WineOrder getWineOrder() {
        return wineOrder;
    }

    public void setWineOrder(WineOrder wineOrder) {
        this.wineOrder = wineOrder;
    }
}
