package com.cesi.client_lourd_negosud.models;

import java.math.BigDecimal;

public class ArticleQuantity {

    private final Integer idArticle;
    private final String articleName;
    private final BigDecimal quantity;

    public ArticleQuantity(Integer id, String name, BigDecimal quantity) {
        this.idArticle = id;
        this.articleName = name;
        this.quantity = quantity;
    }

    // Getters pour les propriétés
    public Integer getIdArticle() {
        return idArticle;
    }

    public String getArticleName() {
        return articleName;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

}
