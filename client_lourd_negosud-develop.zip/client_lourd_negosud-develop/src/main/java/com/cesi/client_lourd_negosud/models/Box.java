package com.cesi.client_lourd_negosud.models;

public class Box {

    int idBox;
    String materialBox;

    public int getIdBox() {
        return idBox;
    }

    public void setIdBox(int idBox) {
        this.idBox = idBox;
    }

    public String getMaterialBox() {
        return materialBox;
    }

    public void setMaterialBox(String materialBox) {
        this.materialBox = materialBox;
    }
}
