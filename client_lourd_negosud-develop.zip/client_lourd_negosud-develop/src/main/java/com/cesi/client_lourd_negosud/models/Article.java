package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.*;


public class Article {

    private final SimpleIntegerProperty idArticle;
    private final SimpleStringProperty articleName;
    private final SimpleStringProperty articleDescription;
    private final SimpleStringProperty grapeVariety;
    private final SimpleStringProperty appellationArticle;
    private final SimpleStringProperty yearProduction;
    private final SimpleFloatProperty alcoholRate;
    private final SimpleFloatProperty articlePrice;
    private final SimpleIntegerProperty minThreshold;
    private final ObjectProperty<Box> box;
    private final ObjectProperty<Rating> rating;
    private final ObjectProperty<Family> family;
    private final ObjectProperty<Supplier> supplier;


    public Article(@JsonProperty("idArticle") int idArticle,
                   @JsonProperty("articleName") String articleName,
                   @JsonProperty("articleDescription")String articleDescription,
                   @JsonProperty("grapeVariety") String grapeVariety,
                   @JsonProperty("appellationArticle") String appellationArticle,
                   @JsonProperty("yearProduction") String yearProduction,
                   @JsonProperty("alcoholRate") float alcoholRate,
                   @JsonProperty("articlePrice") float articlePrice,
                   @JsonProperty("minThreshold") int minThreshold,
                   @JsonProperty("box") Box box,
                   @JsonProperty("rating") Rating rating,
                   @JsonProperty("family") Family family,
                   @JsonProperty("supplier") Supplier supplier) {
        this.idArticle = new SimpleIntegerProperty(idArticle);
        this.articleName = new SimpleStringProperty(articleName);
        this.articleDescription = new SimpleStringProperty(articleDescription);
        this.grapeVariety = new SimpleStringProperty(grapeVariety);
        this.appellationArticle = new SimpleStringProperty(appellationArticle);
        this.yearProduction = new SimpleStringProperty(yearProduction);
        this.alcoholRate = new SimpleFloatProperty(alcoholRate);
        this.articlePrice = new SimpleFloatProperty(articlePrice);
        this.minThreshold = new SimpleIntegerProperty(minThreshold);
        this.box = new SimpleObjectProperty<>(box);
        this.rating = new SimpleObjectProperty<>(rating);
        this.family = new SimpleObjectProperty<>(family);
        this.supplier = new SimpleObjectProperty<>(supplier);
    }

    public int getIdArticle() {
        return idArticle.get();
    }

    public SimpleIntegerProperty idArticleProperty() {
        return idArticle;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle.set(idArticle);
    }

    public String getArticleName() {
        return articleName.get();
    }

    public SimpleStringProperty articleNameProperty() {
        return articleName;
    }

    public void setArticleName(String articleName) {
        this.articleName.set(articleName);
    }

    public String getArticleDescription() {
        return articleDescription.get();
    }

    public SimpleStringProperty articleDescriptionProperty() {
        return articleDescription;
    }

    public void setArticleDescription(String articleDescription) {
        this.articleDescription.set(articleDescription);
    }

    public String getGrapeVariety() {
        return grapeVariety.get();
    }

    public SimpleStringProperty grapeVarietyProperty() {
        return grapeVariety;
    }

    public void setGrapeVariety(String grapeVariety) {
        this.grapeVariety.set(grapeVariety);
    }

    public String getAppellationArticle() {
        return appellationArticle.get();
    }

    public SimpleStringProperty appellationArticleProperty() {
        return appellationArticle;
    }

    public void setAppellationArticle(String appellationArticle) {
        this.appellationArticle.set(appellationArticle);
    }

    public String getYearProduction() {
        return yearProduction.get();
    }

    public SimpleStringProperty yearProductionProperty() {
        return yearProduction;
    }

    public void setYearProduction(String yearProduction) {
        this.yearProduction.set(yearProduction);
    }

    public float getAlcoholRate() {
        return alcoholRate.get();
    }

    public SimpleFloatProperty alcoholRateProperty() {
        return alcoholRate;
    }

    public void setAlcoholRate(float alcoholRate) {
        this.alcoholRate.set(alcoholRate);
    }

    public float getArticlePrice() {
        return articlePrice.get();
    }

    public SimpleFloatProperty articlePriceProperty() {
        return articlePrice;
    }

    public void setArticlePrice(float articlePrice) {
        this.articlePrice.set(articlePrice);
    }

    public int getMinThreshold() {
        return minThreshold.get();
    }

    public SimpleIntegerProperty minThresholdProperty() {
        return minThreshold;
    }

    public void setMinThreshold(int minThreshold) {
        this.minThreshold.set(minThreshold);
    }

    public Box getBox() {
        return box.get();
    }

    public ObjectProperty<Box> boxProperty() {
        return box;
    }

    public void setBox(Box box) {
        this.box.set(box);
    }

    public Rating getRating() {
        return rating.get();
    }

    public ObjectProperty<Rating> ratingProperty() {
        return rating;
    }

    public void setRating(Rating rating) {
        this.rating.set(rating);
    }

    public Family getFamily() {
        return family.get();
    }

    public ObjectProperty<Family> familyProperty() {
        return family;
    }

    public void setFamily(Family family) {
        this.family.set(family);
    }

    public Supplier getSupplier() {
        return supplier.get();
    }

    public ObjectProperty<Supplier> supplierProperty() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier.set(supplier);
    }
}
