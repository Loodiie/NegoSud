package com.cesi.client_lourd_negosud.models;

import java.sql.Timestamp;

public class Payment {

    private int id_payment;
    private Timestamp payment_date;
    private String payment_method;
    private float payment_rate;
    private Invoice invoice;

    public int getId_payment() {
        return id_payment;
    }

    public void setId_payment(int id_payment) {
        this.id_payment = id_payment;
    }

    public Timestamp getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(Timestamp payment_date) {
        this.payment_date = payment_date;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public float getPayment_rate() {
        return payment_rate;
    }

    public void setPayment_rate(float payment_rate) {
        this.payment_rate = payment_rate;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
