package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.sql.Timestamp;

public class Stock {

    private final SimpleIntegerProperty id;
    private final ObjectProperty<Timestamp> dateIn;
    private final ObjectProperty<Timestamp> dateOut;
    private final SimpleIntegerProperty quantityIn;
    private final SimpleIntegerProperty quantityOut;
    private final ObjectProperty<Article> article;

    public Stock(@JsonProperty("id") Integer id,
                 @JsonProperty("dateIn") Timestamp dateIn,
                 @JsonProperty("dateOut") Timestamp dateOut,
                 @JsonProperty("quantityIn") Integer quantityIn,
                 @JsonProperty("quantityOut") Integer quantityOut,
                 @JsonProperty("article") Article article) {
        this.id = new SimpleIntegerProperty(id);
        this.dateIn = new SimpleObjectProperty<>(dateIn);
        this.dateOut = new SimpleObjectProperty<>(dateOut);
        this.quantityIn = new SimpleIntegerProperty(quantityIn);
        this.quantityOut = new SimpleIntegerProperty(quantityOut);
        this.article = new SimpleObjectProperty<>(article);
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public Timestamp getDateIn() {
        return dateIn.get();
    }

    public ObjectProperty<Timestamp> dateInProperty() {
        return dateIn;
    }

    public void setDateIn(Timestamp dateIn) {
        this.dateIn.set(dateIn);
    }

    public Timestamp getDateOut() {
        return dateOut.get();
    }

    public ObjectProperty<Timestamp> dateOutProperty() {
        return dateOut;
    }

    public void setDateOut(Timestamp dateOut) {
        this.dateOut.set(dateOut);
    }

    public int getQuantityIn() {
        return quantityIn.get();
    }

    public SimpleIntegerProperty quantityInProperty() {
        return quantityIn;
    }

    public void setQuantityIn(int quantityIn) {
        this.quantityIn.set(quantityIn);
    }

    public int getQuantityOut() {
        return quantityOut.get();
    }

    public SimpleIntegerProperty quantityOutProperty() {
        return quantityOut;
    }

    public void setQuantityOut(int quantityOut) {
        this.quantityOut.set(quantityOut);
    }

    public Article getArticle() {
        return article.get();
    }

    public ObjectProperty<Article> articleProperty() {
        return article;
    }

    public void setArticle(Article article) {
        this.article.set(article);
    }
}
