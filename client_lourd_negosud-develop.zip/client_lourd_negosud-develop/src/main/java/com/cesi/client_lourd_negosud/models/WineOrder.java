package com.cesi.client_lourd_negosud.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.sql.Timestamp;

public class WineOrder {

    private final SimpleIntegerProperty id;
    private final ObjectProperty<Timestamp> date;
    private final ObjectProperty<String> orderStatus;
    private final ObjectProperty<String> type;
    private final ObjectProperty<String> cartStatus;
    private final ObjectProperty<Address> address;
    private final ObjectProperty<Supplier> supplier;
    private final ObjectProperty<Users> user;

    public WineOrder(@JsonProperty("id") Integer id,
                     @JsonProperty("date") Timestamp date,
                     @JsonProperty("orderStatus") String orderStatus,
                     @JsonProperty("type") String type,
                     @JsonProperty("cartStatus") String cartStatus,
                     @JsonProperty("address") Address address,
                     @JsonProperty("supplier") Supplier supplier,
                     @JsonProperty("user") Users user) {
        this.id = new SimpleIntegerProperty(id);
        this.date = new SimpleObjectProperty<>(date);
        this.orderStatus = new SimpleObjectProperty<>(orderStatus);
        this.type = new SimpleObjectProperty<>(type);
        this.cartStatus = new SimpleObjectProperty<>(cartStatus);
        this.address = new SimpleObjectProperty<>(address);
        this.supplier = new SimpleObjectProperty<>(supplier);
        this.user = new SimpleObjectProperty<>(user);
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public Timestamp getDate() {
        return date.get();
    }

    public ObjectProperty<Timestamp> dateProperty() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date.set(date);
    }

    public String getOrderStatus() {
        return orderStatus.get();
    }

    public ObjectProperty<String> orderStatusProperty() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus.set(orderStatus);
    }

    public String getType() {
        return type.get();
    }

    public ObjectProperty<String> typeProperty() {
        return type;
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public String getCartStatus() {
        return cartStatus.get();
    }

    public ObjectProperty<String> cartStatusProperty() {
        return cartStatus;
    }

    public void setCartStatus(String cartStatus) {
        this.cartStatus.set(cartStatus);
    }

    public Address getAddress() {
        return address.get();
    }

    public ObjectProperty<Address> addressProperty() {
        return address;
    }

    public void setAddress(Address address) {
        this.address.set(address);
    }

    public Supplier getSupplier() {
        return supplier.get();
    }

    public ObjectProperty<Supplier> supplierProperty() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier.set(supplier);
    }

    public Users getUsers() {
        return user.get();
    }

    public ObjectProperty<Users> usersProperty() {
        return user;
    }

    public void setUsers(Users users) {
        this.user.set(users);
    }
}