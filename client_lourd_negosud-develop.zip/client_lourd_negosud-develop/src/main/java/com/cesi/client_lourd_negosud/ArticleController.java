package com.cesi.client_lourd_negosud;

import com.cesi.client_lourd_negosud.dao.ArticleDAO;
import com.cesi.client_lourd_negosud.models.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class ArticleController {

    @FXML
    private Button buttonSearchArticleById;
    @FXML
    private TextField fieldSearchArticleById;

    @FXML
    private Button buttonGoToAddArticle;

    @FXML
    private Button buttonGoToUpdateArticle;

    @FXML
    private Button buttonDeleteArticle;

    @FXML
    private TableView<Article> articleTable;

    @FXML
    private TableColumn<Article, Integer> idArticleColumn;
    @FXML
    private TableColumn<Article, String> articleNameColumn;
    @FXML
    private TableColumn<Article, String> articleDescriptionColumn;
    @FXML
    private TableColumn<Article, String> grapeVarietyColumn;
    @FXML
    private TableColumn<Article, String> appellationArticleColumn;
    @FXML
    private TableColumn<Article, String> yearProductionColumn;
    @FXML
    private TableColumn<Article, Float> alcoholRateColumn;
    @FXML
    private TableColumn<Article, Float> articlePriceColumn;
    @FXML
    private TableColumn<Article, Integer> minThresholdColumn;
    @FXML
    private TableColumn<Article, String> boxColumn;
    @FXML
    private TableColumn<Article, String> familyColumn;
    @FXML
    private TableColumn<Article, String> supplierColumn;

    private final ArticleDAO articleDAO = new ArticleDAO();

    @FXML
    public void initialize() {
        // On charge les données depuis l'API dans une liste
        List<Article> articleList = articleDAO.getAllArticles();

        // On lie les données aux champs du tableau (nom des colonnes)
        idArticleColumn.setCellValueFactory(cellData -> cellData.getValue().idArticleProperty().asObject());
        articleNameColumn.setCellValueFactory(cellData -> cellData.getValue().articleNameProperty());
        articleDescriptionColumn.setCellValueFactory(cellData -> cellData.getValue().articleDescriptionProperty());
        grapeVarietyColumn.setCellValueFactory(cellData -> cellData.getValue().grapeVarietyProperty());
        appellationArticleColumn.setCellValueFactory(cellData -> cellData.getValue().appellationArticleProperty());
        yearProductionColumn.setCellValueFactory(cellData -> cellData.getValue().yearProductionProperty());
        alcoholRateColumn.setCellValueFactory(cellData -> cellData.getValue().alcoholRateProperty().asObject());
        articlePriceColumn.setCellValueFactory(cellData -> cellData.getValue().articlePriceProperty().asObject());
        minThresholdColumn.setCellValueFactory(cellData -> cellData.getValue().minThresholdProperty().asObject());
        boxColumn.setCellValueFactory(cellData -> {
            Article article = cellData.getValue();
            if (article != null) {
                Box box = article.getBox();
                if (box != null) {
                    return new SimpleStringProperty(String.valueOf(box.getIdBox()));
                }
            }
            return new SimpleStringProperty(""); // Retourne une string vide si la Box est null
        });
        familyColumn.setCellValueFactory(cellData -> {
            Article article = cellData.getValue();
            if (article != null) {
                Family family = article.getFamily();
                if (family != null) {
                    return new SimpleStringProperty(String.valueOf(family.getFamilyName()));
                }
            }
            return new SimpleStringProperty(""); // Retourne une string vide si la Family est null
        });
        supplierColumn.setCellValueFactory(cellData -> {
            Article article = cellData.getValue();
            if (article != null) {
                Supplier supplier = article.getSupplier();
                if (supplier != null) {
                    return new SimpleStringProperty(String.valueOf(supplier.getSupplierName()));
                }
            }
            return new SimpleStringProperty(""); // Retourner une chaîne vide si le Supplier est null
        });

        // Ajoute les données au tableau
        articleTable.getItems().addAll(articleList);
    }

    private static Stage deleteArticleStage;
    @FXML
    void DeleteArticle(ActionEvent event) {
        // Vérifie si la scène est déjà ouverte (pour qu'il ne soit pas possible d'ouvrir une autre fenêtre de suppression d'article en même temps)
        if (deleteArticleStage == null || !deleteArticleStage.isShowing()) {
            try {
                // Charge le fichier FXML
                FXMLLoader loader = new FXMLLoader(getClass().getResource("deleteArticle.fxml"));
                Parent root = loader.load();

                // Créé une nouvelle scène
                Scene scene = new Scene(root);

                // Créé un nouveau stage pour ne pas fermer la page actuelle mais s'ajouter en plus
                deleteArticleStage = new Stage();

                // Met la nouvelle scène dans le nouveau stage
                deleteArticleStage.setScene(scene);

                // Affiche le nouveau stage
                deleteArticleStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Stage addArticleStage;

    @FXML
    void GoToAddArticle(ActionEvent event) {
        // Vérifie si la scène est déjà ouverte (pour qu'il ne soit pas possible d'ouvrir une autre fenêtre d'ajout d'article en même temps)
        if (addArticleStage == null || !addArticleStage.isShowing()) {
            try {
                // Charge le fichier FXML
                FXMLLoader loader = new FXMLLoader(getClass().getResource("addArticle.fxml"));
                Parent root = loader.load();

                // Créé une nouvelle scène
                Scene scene = new Scene(root);

                // Créé un nouveau stage pour ne pas fermer la page actuelle mais s'ajouter en plus
                addArticleStage = new Stage();

                // Met la nouvelle scène dans le nouveau stage
                addArticleStage.setScene(scene);

                // Affiche le nouveau stage
                addArticleStage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Stage updateArticleStage;

    @FXML
    void GoToUpdateArticle(ActionEvent event) {
        // Vérifie si la scène est déjà ouverte (pour qu'il ne soit pas possible d'ouvrir une autre fenêtre d'update d'article en même temps)
        if (updateArticleStage == null || !updateArticleStage.isShowing()) {
            try {
                // Charge le fichier FXML
                FXMLLoader loader = new FXMLLoader(getClass().getResource("updateArticle.fxml"));
                Parent root = loader.load();

                // Créé une nouvelle scène
                Scene scene = new Scene(root);

                // Créé un nouveau stage pour ne pas fermer la page actuelle mais s'ajouter en plus
                updateArticleStage = new Stage();

                // Met la nouvelle scène dans le nouveau stage
                updateArticleStage.setScene(scene);

                // Affiche le nouveau stage
                updateArticleStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void filterArticleById(ActionEvent event) {

        try {
            int id = Integer.parseInt(fieldSearchArticleById.getText());

            Article article = ArticleDAO.getArticleById(id);

            // Supprime les données existantes dans le tableau
            articleTable.getItems().clear();

            // Ajoute l'article recherché dans le tableau
            if (article != null) {
                articleTable.getItems().add(article);
            }
        } catch (NumberFormatException e) {
            // Exception dans le cas où l'utilisateur entre une valeur de mauvais type
            e.printStackTrace();
        }

    }

}
